<?php
session_start();
require_once 'connection.php';

// Security Check
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$errors  = [];
$product = null;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id          = trim($_POST['id'] ?? '');
    $name        = trim($_POST['name'] ?? '');
    $price       = trim($_POST['price'] ?? '');
    $saleprice   = trim($_POST['saleprice'] ?? '');
    $platform    = trim($_POST['platform'] ?? '');
    $category    = trim($_POST['category'] ?? '');
    $quantity    = trim($_POST['quantity'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $imageurl    = trim($_POST['imageurl'] ?? '');
    $ispreowned  = isset($_POST['ispreowned']) ? 1 : 0;

    if ($id === '' || !ctype_digit($id)) {
        $errors[] = "Invalid product ID.";
    }

    // Required fields
    if ($name === '' || $price === '' || $platform === '' || $category === '' || $quantity === '' || $imageurl === '') {
        $errors[] = "Name, price, platform, category, quantity, and image URL are required.";
    }

    // Length checks
    if ($name !== '' && strlen($name) > 255) {
        $errors[] = "Product name is too long (max 255 characters).";
    }
    if ($imageurl !== '' && strlen($imageurl) > 255) {
        $errors[] = "Image URL is too long (max 255 characters).";
    }

    // Numeric validation
    if ($price !== '') {
        if (!is_numeric($price) || (float)$price <= 0) {
            $errors[] = "Price must be a positive number.";
        }
    }

    if ($saleprice === '') {
        $saleprice = 0;
    } else {
        if (!is_numeric($saleprice) || (float)$saleprice < 0) {
            $errors[] = "Sale price must be a number greater than or equal to 0.";
        } elseif (is_numeric($price) && (float)$saleprice > (float)$price) {
            $errors[] = "Sale price cannot be greater than the regular price.";
        }
    }

    if ($quantity !== '') {
        if (!ctype_digit($quantity) || (int)$quantity < 0) {
            $errors[] = "Quantity must be a non-negative whole number.";
        }
    }

    if (empty($errors)) {
        $idVal        = (int)$id;
        $priceVal     = (float)$price;
        $salepriceVal = (float)$saleprice;
        $quantityVal  = (int)$quantity;

        $sql = "UPDATE products
                SET name = ?, price = ?, saleprice = ?, platform = ?, category = ?, quantity = ?, imageurl = ?, ispreowned = ?, description = ?
                WHERE id = ?";

        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param(
                "sddssisisi",
                $name,
                $priceVal,
                $salepriceVal,
                $platform,
                $category,
                $quantityVal,
                $imageurl,
                $ispreowned,
                $description,
                $idVal
            );

            if ($stmt->execute()) {
                header("Location: admin.php");
                exit;
            } else {
                $errors[] = "Error updating record: " . $conn->error;
            }
        } else {
            $errors[] = "Database error: could not prepare statement.";
        }
    }

    // If there are errors, keep submitted values
    if (!empty($errors)) {
        $product = [
            'id'          => $id,
            'name'        => $name,
            'price'       => $price,
            'saleprice'   => $saleprice,
            'platform'    => $platform,
            'category'    => $category,
            'quantity'    => $quantity,
            'imageurl'    => $imageurl,
            'description' => $description,
            'ispreowned'  => $ispreowned
        ];
    }
} else {
    // Initial load: fetch product by id
    if (isset($_GET['id']) && ctype_digit($_GET['id'])) {
        $id = (int)$_GET['id'];
        $sql = "SELECT * FROM products WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $product = $result->fetch_assoc();
            } else {
                $errors[] = "Product not found.";
            }
        } else {
            $errors[] = "Database error: could not prepare statement.";
        }
    } else {
        $errors[] = "No valid product ID provided.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f4f6;
        }
        .page-wrapper {
            max-width: 900px;
            margin: 30px auto;
            padding: 0 15px;
        }
        .card {
            background: #ffffff;
            border-radius: 10px;
            padding: 20px 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        h1 {
            margin-bottom: 15px;
            text-align: center;
        }
        .subtitle {
            text-align: center;
            color: #555;
            margin-bottom: 20px;
            font-size: 0.95rem;
        }
        form .form-group {
            margin-bottom: 12px;
        }
        form label {
            display: block;
            font-weight: bold;
            margin-bottom: 4px;
        }
        form input[type="text"],
        form input[type="number"],
        form textarea {
            width: 100%;
            padding: 8px 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 0.95rem;
        }
        textarea {
            resize: vertical;
        }
        .inline-row {
            display: flex;
            gap: 10px;
        }
        .inline-row .form-group {
            flex: 1;
        }
        .checkbox-row {
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .checkbox-row input[type="checkbox"] {
            width: auto;
        }
        .btn-primary {
            background: #2563eb;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.95rem;
        }
        .btn-primary:hover {
            background: #1d4ed8;
        }
        .back-link {
            margin-top: 15px;
            text-align: center;
        }
        .back-link a {
            color: #2563eb;
            text-decoration: none;
        }
        .error-box {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #b91c1c;
            padding: 10px 12px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<div class="page-wrapper">
    <div class="card">
        <h1>Edit Product</h1>
        <p class="subtitle">Update the details of this product and save your changes.</p>

        <?php if (!empty($errors)): ?>
            <div class="error-box">
                <?php echo htmlspecialchars(implode(' ', $errors)); ?>
            </div>
        <?php endif; ?>

        <?php if ($product): ?>
            <form method="post" action="editproduct.php">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id']); ?>">

                <div class="form-group">
                    <label>Product Name *</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                </div>

                <div class="inline-row">
                    <div class="form-group">
                        <label>Platform *</label>
                        <input type="text" name="platform" value="<?php echo htmlspecialchars($product['platform']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Category *</label>
                        <input type="text" name="category" value="<?php echo htmlspecialchars($product['category']); ?>" required>
                    </div>
                </div>

                <div class="inline-row">
                    <div class="form-group">
                        <label>Price * ($)</label>
                        <input type="number" step="0.01" name="price" value="<?php echo htmlspecialchars($product['price']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Sale Price ($, optional)</label>
                        <input type="number" step="0.01" name="saleprice" value="<?php echo htmlspecialchars($product['saleprice']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Quantity * (in stock)</label>
                        <input type="number" name="quantity" min="0" value="<?php echo htmlspecialchars($product['quantity']); ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Image URL *</label>
                    <input type="text" name="imageurl" value="<?php echo htmlspecialchars($product['imageurl']); ?>" required>
                </div>

                <div class="form-group">
                    <label>Description (optional)</label>
                    <textarea name="description" rows="4"><?php echo htmlspecialchars($product['description']); ?></textarea>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" name="ispreowned" <?php if (!empty($product['ispreowned'])) echo 'checked'; ?>>
                    <span>Is Pre-Owned?</span>
                </div>

                <div style="margin-top:18px; text-align:center;">
                    <button type="submit" class="btn-primary">Save Changes</button>
                </div>
            </form>
        <?php else: ?>
            <p>No product data to display.</p>
        <?php endif; ?>

        <div class="back-link">
            <a href="admin.php">&larr; Back to Admin Panel</a>
        </div>
    </div>
</div>

</body>
</html>
