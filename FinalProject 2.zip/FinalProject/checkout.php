<?php
session_start();
require_once 'connection.php';

// Must be logged in and have items
if (!isset($_SESSION['loggedin']) || empty($_SESSION['cart'])) {
    header("Location: home.php");
    exit;
}

$user_id = $_SESSION['id'];   // from login.php
$total   = 0.0;

// Loop through cart: calculate total AND subtract stock
foreach ($_SESSION['cart'] as $product_id => $quantity) {

    // 1) Get the product price (use saleprice if > 0)
    $sql = "SELECT price, saleprice FROM products WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $unit_price = ($row['saleprice'] > 0) ? $row['saleprice'] : $row['price'];
        $total += $unit_price * $quantity;
    }
    $stmt->close();

    // 2) Update stock: quantity = quantity - purchased amount
    $sql = "UPDATE products SET quantity = quantity - ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $quantity, $product_id);
    $stmt->execute();
    $stmt->close();
}

// 3) Create an order row in the ORDERS table
$sql = "INSERT INTO orders (user_id, total) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("id", $user_id, $total);
$stmt->execute();
$order_id = $stmt->insert_id;   // <-- this is the Order ID
$stmt->close();

// 4) Empty the cart
unset($_SESSION['cart']);

// 5) Redirect with Order ID shown in alert
echo "<script>
alert('Thank you for your purchase! Your Order ID is #{$order_id}.');
window.location.href='home.php';
</script>";
?>
