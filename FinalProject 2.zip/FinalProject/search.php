<?php
session_start();
require_once 'connection.php';

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search - Game Zone</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/x-icon" href="images/favicon/favicon.ico">
</head>
<body class="mainbody">

<?php include 'navbar.php'; ?>

<div class="mainheader">
    <br><br>
    <h2 style="color:#FFEB3B; text-align:center;">Search Results</h2>
    <?php if ($q !== ''): ?>
        <p style="color:white; text-align:center;">Results for: <strong><?php echo htmlspecialchars($q); ?></strong></p>
    <?php endif; ?>
    <br><hr><br>
</div>

<div class="maincontent">
    <div class="columns">
        <div class="leftcolumn"></div>
        <div class="middlecolumn">
            <?php
            if ($q === '') {
                echo "<p style='color:white;'>Please enter a search term.</p>";
            } else {
                $like = '%' . $q . '%';
                $sql = "SELECT * FROM products
                        WHERE name LIKE ? OR description LIKE ?
                        ORDER BY name";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $like, $like);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows === 0) {
                    echo "<p style='color:white;'>No products found for <strong>" . htmlspecialchars($q) . "</strong>.</p>";
                } else {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <div class="product">
                            <div class="productimage">
                                <img src="<?php echo $row['imageurl']; ?>"
                                     alt="<?php echo htmlspecialchars($row['name']); ?>">
                            </div>

                            <div class="productdescription">
                                <h3 class="productname">
                                    <?php echo htmlspecialchars($row['name']); ?>
                                </h3>

                                <?php
                                if ($row['saleprice'] > 0) {
                                    echo '<p class="productprice" style="text-decoration:line-through; color:gray;">$'
                                         . $row['price'] . '</p>';
                                    echo '<p class="productprice" style="color:red;">$'
                                         . $row['saleprice'] . '</p>';
                                } else {
                                    echo '<p class="productprice">$' . $row['price'] . '</p>';
                                }

                                if ($row['quantity'] > 0) {
                                    echo '<a href="cart.php?add=' . $row['id']
                                         . '" class="addcart" style="display:block; text-align:center; text-decoration:none; padding-top:10px;">Add to Cart</a>';
                                    echo '<p style="font-size:12px; color:black; margin-top:5px;">In Stock: '
                                         . $row['quantity'] . '</p>';
                                } else {
                                    echo '<button class="addcart" style="background-color:grey; cursor:not-allowed;" disabled>Out of Stock</button>';
                                }
                                ?>
                            </div>

                            <div class="gamedes">
                                <p class="paradescription">
                                    <?php echo htmlspecialchars($row['description']); ?>
                                </p>
                            </div>
                        </div>
                        <br>
                        <?php
                    }
                }

                $stmt->close();
            }
            ?>
        </div>
        <div class="rightcolumn"></div>
    </div>
</div>

<div class="footermain">
    <br><hr><br>
    <footer>
        <p>&copy; 2025 Game Zone. All rights reserved.</p>
        <p>Contact us at: <a href="mailto:gamezone@outlook.com">gamezone@outlook.com</a></p>
    </footer>
    <br>
</div>

</body>
</html>
