<?php
session_start();
require_once 'connection.php';

// Only logged-in users can see profile
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['id'];
$success = '';
$errors  = [];

// 1. Get basic user info
$userSql = "SELECT firstname, lastname, username, email FROM users WHERE id = ?";
$userStmt = $conn->prepare($userSql);
$userStmt->bind_param("i", $userId);
$userStmt->execute();
$userResult = $userStmt->get_result();
$user = $userResult->fetch_assoc();

// If somehow no user found, force logout
if (!$user) {
    header("Location: logout.php");
    exit;
}

// 2. Get address info (if it exists)
$addressSql = "SELECT * FROM addresses WHERE user_id = ?";
$addressStmt = $conn->prepare($addressSql);
$addressStmt->bind_param("i", $userId);
$addressStmt->execute();
$addressResult = $addressStmt->get_result();
$address = $addressResult->fetch_assoc();

// Default address values
$address_line1 = $address['address_line1'] ?? '';
$address_line2 = $address['address_line2'] ?? '';
$city          = $address['city'] ?? '';
$state         = $address['state'] ?? '';
$postal_code   = $address['postal_code'] ?? '';
$country       = $address['country'] ?? 'USA';
$phone         = $address['phone'] ?? '';

// 3. Handle address form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address_line1 = trim($_POST['address_line1'] ?? '');
    $address_line2 = trim($_POST['address_line2'] ?? '');
    $city          = trim($_POST['city'] ?? '');
    $state         = trim($_POST['state'] ?? '');
    $postal_code   = trim($_POST['postal_code'] ?? '');
    $country       = trim($_POST['country'] ?? '');
    $phone         = trim($_POST['phone'] ?? '');

    // Simple server-side validation
    if ($address_line1 === '' || $city === '' || $state === '' || $postal_code === '' || $country === '') {
        $errors[] = "Address line 1, city, state, postal code, and country are required.";
    }

    if ($phone !== '' && !preg_match('/^[0-9+\-\s()]+$/', $phone)) {
        $errors[] = "Please enter a valid phone number format.";
    }

    if (empty($errors)) {
        if ($address) {
            // Update existing address
            $updateSql = "
                UPDATE addresses
                SET address_line1 = ?, address_line2 = ?, city = ?, state = ?, postal_code = ?, country = ?, phone = ?
                WHERE user_id = ?
            ";
            $stmt = $conn->prepare($updateSql);
            $stmt->bind_param(
                "sssssssi",
                $address_line1,
                $address_line2,
                $city,
                $state,
                $postal_code,
                $country,
                $phone,
                $userId
            );
            if ($stmt->execute()) {
                $success = "Your address has been updated.";
            } else {
                $errors[] = "Error updating address. Please try again.";
            }
        } else {
            // Insert new address
            $insertSql = "
                INSERT INTO addresses
                (user_id, address_line1, address_line2, city, state, postal_code, country, phone)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ";
            $stmt = $conn->prepare($insertSql);
            $stmt->bind_param(
                "isssssss",
                $userId,
                $address_line1,
                $address_line2,
                $city,
                $state,
                $postal_code,
                $country,
                $phone
            );
            if ($stmt->execute()) {
                $success = "Your address has been saved.";
            } else {
                $errors[] = "Error saving address. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Profile - Game Zone</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .profile-wrapper {
            max-width: 700px;
            margin: 40px auto;
            background: white;
            padding: 20px 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .profile-section-title {
            margin-top: 10px;
            margin-bottom: 8px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 4px;
            font-weight: bold;
        }
        .profile-row {
            margin-bottom: 6px;
        }
        .profile-label {
            font-weight: bold;
        }
        .address-form input {
            width: 100%;
            padding: 8px 10px;
            margin-bottom: 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        .address-form button {
            padding: 8px 14px;
            border-radius: 6px;
            border: none;
            background: #2563eb;
            color: white;
            cursor: pointer;
        }
        .address-form button:hover {
            background: #1d4ed8;
        }
        .msg-success {
            background: #dcfce7;
            border: 1px solid #bbf7d0;
            color: #166534;
            padding: 8px 10px;
            border-radius: 6px;
            margin-bottom: 10px;
            font-size: 0.9rem;
        }
        .msg-error {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #b91c1c;
            padding: 8px 10px;
            border-radius: 6px;
            margin-bottom: 10px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body class="mainbody">

<?php include 'navbar.php'; ?>

<div class="profile-wrapper">
    <h2>My Profile</h2>

    <?php if (!empty($success)): ?>
        <div class="msg-success">
            <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div class="msg-error">
            <?php echo htmlspecialchars(implode(' ', $errors)); ?>
        </div>
    <?php endif; ?>

    <div class="profile-section-title">Account Information</div>
    <div class="profile-row">
        <span class="profile-label">Name:</span>
        <?php echo htmlspecialchars($user['firstname'] . ' ' . $user['lastname']); ?>
    </div>
    <div class="profile-row">
        <span class="profile-label">Username:</span>
        <?php echo htmlspecialchars($user['username']); ?>
    </div>
    <div class="profile-row">
        <span class="profile-label">Email:</span>
        <?php echo htmlspecialchars($user['email']); ?>
    </div>

    <div class="profile-section-title" style="margin-top:20px;">Address Information</div>

    <form method="post" action="profile.php" class="address-form">
        <input
            type="text"
            name="address_line1"
            placeholder="Address Line 1 *"
            value="<?php echo htmlspecialchars($address_line1); ?>"
            required
        >
        <input
            type="text"
            name="address_line2"
            placeholder="Address Line 2 (optional)"
            value="<?php echo htmlspecialchars($address_line2); ?>"
        >
        <input
            type="text"
            name="city"
            placeholder="City *"
            value="<?php echo htmlspecialchars($city); ?>"
            required
        >
        <input
            type="text"
            name="state"
            placeholder="State / Province *"
            value="<?php echo htmlspecialchars($state); ?>"
            required
        >
        <input
            type="text"
            name="postal_code"
            placeholder="Postal Code *"
            value="<?php echo htmlspecialchars($postal_code); ?>"
            required
        >
        <input
            type="text"
            name="country"
            placeholder="Country *"
            value="<?php echo htmlspecialchars($country); ?>"
            required
        >
        <input
            type="text"
            name="phone"
            placeholder="Phone (optional)"
            value="<?php echo htmlspecialchars($phone); ?>"
        >

        <button type="submit">
            <?php echo $address ? 'Update Address' : 'Save Address'; ?>
        </button>
    </form>
</div>

</body>
</html>
