<?php
session_start();
require_once 'connection.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Delete User Logic
if (isset($_GET['delete_user'])) {
    $id = $_GET['delete_user'];
    if (ctype_digit($id)) {
        $conn->query("DELETE FROM users WHERE id=$id");
    }
    header("Location: admin.php");
    exit;
}

// Delete Product Logic
if (isset($_GET['delete_product'])) {
    $id = $_GET['delete_product'];
    if (ctype_digit($id)) {
        $conn->query("DELETE FROM products WHERE id=$id");
    }
    header("Location: admin.php");
    exit;
}

// Delete Feedback Logic
if (isset($_GET['delete_feedback'])) {
    $id = $_GET['delete_feedback'];
    if (ctype_digit($id)) {
        $stmt = $conn->prepare("DELETE FROM feedback WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
    header("Location: admin.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Embedded CSS for Admin Table Layout */
        .admin-wrapper { padding: 50px; color: black; }
        .styled-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin: 25px 0;
            box-shadow: 0 0 20px rgba(0,0,0,0.15);
        }
        .styled-table th, .styled-table td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .styled-table th {
            background-color: #FF6F61;
            color: white;
        }
        .btn-action {
            padding: 5px 10px;
            text-decoration: none;
            color: white;
            border-radius: 3px;
            margin-right: 5px;
            font-size: 14px;
        }
        .btn-edit { background-color: green; }
        .btn-delete { background-color: red; }
        .btn-add {
            background-color: #333;
            color: #FFEB3B;
            padding: 10px 20px;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            display: inline-block;
            margin-bottom: 10px;
        }
    </style>
</head>
<body class="mainbody">
    
    <?php include 'navbar.php'; ?>

    <div class="admin-wrapper">
        
        <!-- MANAGE USERS -->
        <h2 style="color: #FFEB3B; border-bottom: 2px solid white;">Manage Users</h2>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Password (hashed/plain)</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $result = $conn->query("SELECT * FROM users");
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>".htmlspecialchars($row['id'])."</td>
                    <td>".htmlspecialchars($row['firstname'])."</td>
                    <td>".htmlspecialchars($row['lastname'])."</td>
                    <td>".htmlspecialchars($row['username'])."</td>
                    <td>".htmlspecialchars($row['email'])."</td>
                    <td>".htmlspecialchars($row['password'])."</td>
                    <td>".htmlspecialchars($row['role'])."</td>
                    <td>
                        <a href='edit_user.php?id=".$row['id']."' class='btn-action btn-edit'>Edit</a>
                        <a href='admin.php?delete_user=".$row['id']."' class='btn-action btn-delete' onclick='return confirm(\"Delete User?\")'>Delete</a>
                    </td>
                </tr>";
            }
            ?>
            </tbody>
        </table>

        <br><br>

        <!-- MANAGE PRODUCTS -->
        <div style="display:flex; justify-content:space-between; align-items:center;">
            <h2 style="color: #FFEB3B; border-bottom: 2px solid white;">Manage Products</h2>
            <a href="addproduct.php" class="btn-add">+ Add New Product</a>
        </div>
        
        <table class="styled-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Sale Price</th>
                    <th>Platform</th>
                    <th>Category</th>
                    <th>Is pre-owned?</th>
                    <th>Stock</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $result = $conn->query("SELECT * FROM products");
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>".htmlspecialchars($row['id'])."</td>
                    <td>".htmlspecialchars($row['name'])."</td>
                    <td>$".htmlspecialchars($row['price'])."</td>
                    <td>$".htmlspecialchars($row['saleprice'])."</td>
                    <td>".htmlspecialchars($row['platform'])."</td>
                    <td>".htmlspecialchars($row['category'])."</td>
                    <td>".htmlspecialchars($row['ispreowned'])."</td>
                    <td>".htmlspecialchars($row['quantity'])."</td>
                    <td>
                        <a href='editproduct.php?id=".$row['id']."' class='btn-action btn-edit'>Edit</a>
                        <a href='admin.php?delete_product=".$row['id']."' class='btn-action btn-delete' onclick='return confirm(\"Delete Product?\")'>Delete</a>
                    </td>
                </tr>";
            }
            ?>
            </tbody>
        </table>

        <br><br>

        <!-- RECENT ORDERS -->
        <h2 style="color: #FFEB3B; border-bottom: 2px solid white;">Recent Orders</h2>

        <table class="styled-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>User</th>
                    <th>Total ($)</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $sql = "SELECT o.id, o.total, o.created_at, o.status, u.username
                    FROM orders o
                    LEFT JOIN users u ON o.user_id = u.id
                    ORDER BY o.created_at DESC
                    LIMIT 50";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>#' . htmlspecialchars($row['id']) . '</td>';
                    echo '<td>' . htmlspecialchars($row['username'] ?? 'Unknown') . '</td>';
                    echo '<td>' . number_format($row['total'], 2) . '</td>';
                    echo '<td>' . htmlspecialchars($row['created_at']) . '</td>';
                    echo '<td>' . htmlspecialchars($row['status']) . '</td>';
                    echo '</tr>';
                }
            } else {
                echo "<tr><td colspan='5'>No orders yet.</td></tr>";
            }
            ?>
            </tbody>
        </table>

        <br><br>

        <!-- FEEDBACK SECTION -->
        <h2 style="color: #FFEB3B; border-bottom: 2px solid white;">Feedback</h2>

        <table class="styled-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Username (if logged in)</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $sql = "SELECT f.id, f.name, f.email, f.message, f.created_at, u.username
                    FROM feedback f
                    LEFT JOIN users u ON f.user_id = u.id
                    ORDER BY f.created_at DESC";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($row['id']) . '</td>';
                    echo '<td>' . htmlspecialchars($row['name']) . '</td>';
                    echo '<td>' . htmlspecialchars($row['email']) . '</td>';
                    echo '<td>' . htmlspecialchars($row['username'] ?? 'Guest') . '</td>';
                    echo '<td>' . nl2br(htmlspecialchars($row['message'])) . '</td>';
                    echo '<td>' . htmlspecialchars($row['created_at']) . '</td>';
                    echo '<td>
                            <a href="admin.php?delete_feedback=' . $row['id'] . '"
                               class="btn-action btn-delete"
                               onclick="return confirm(\'Delete this feedback entry?\')">
                               Delete
                            </a>
                          </td>';
                    echo '</tr>';
                }
            } else {
                echo "<tr><td colspan='7'>No feedback has been submitted yet.</td></tr>";
            }
            ?>
            </tbody>
        </table>

    </div>
</body>
</html>
