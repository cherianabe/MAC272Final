<?php
session_start();
require_once 'connection.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $user_id = isset($_SESSION['id']) ? $_SESSION['id'] : null;

    if ($name === '' || $email === '' || $message === '') {
        $error = "Please fill out all fields.";
    } else {
        $sql = "INSERT INTO feedback (user_id, name, email, message) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        
        // user_id can be NULL if not logged in
        if ($user_id === null) {
            $null = null;
            $stmt->bind_param("isss", $null, $name, $email, $message);
        } else {
            $stmt->bind_param("isss", $user_id, $name, $email, $message);
        }

        if ($stmt->execute()) {
            $success = "Thank you for your feedback!";
        } else {
            $error = "Something went wrong. Please try again later.";
        }

        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feedback - Game Zone</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/x-icon" href="images/favicon/favicon.ico">
</head>
<body class="mainbody">

<?php include 'navbar.php'; ?>

<div class="mainheader">
    <br><br>
    <h2 style="color:#FFEB3B; text-align:center;">Feedback</h2>
    <p style="color:white; text-align:center;">Tell us what you think about Game Zone.</p>
    <br><hr><br>
</div>

<div class="maincontent">
    <div class="columns">
        <div class="leftcolumn"></div>
        <div class="middlecolumn">
            <div class="form-container" style="width: 500px; margin: 0 auto;">
                <?php if ($success): ?>
                    <p style="color: #66FF00;"><?php echo $success; ?></p>
                <?php endif; ?>

                <?php if ($error): ?>
                    <p style="color: red;"><?php echo $error; ?></p>
                <?php endif; ?>

                <form method="post" action="feedback.php">
                    <input type="text" name="name" placeholder="Your Name" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                    <textarea name="message" placeholder="Your Feedback"
                              style="width:100%; height:150px; padding:10px; margin-bottom:15px;" required></textarea>
                    <button type="submit">Submit Feedback</button>
                </form>
            </div>
        </div>
        <div class="rightcolumn"></div>
    </div>
</div>

<div class="footermain">
    <br><hr><br>
    <footer>
        <p>&copy; 2025 Game Zone. All rights reserved.</p>
        <p>Contact us at: <a href="mailto:gamezone@outlook.com">gamezone@outlook.com</a></p>
    </footer>
    <br>
</div>

</body>
</html>
