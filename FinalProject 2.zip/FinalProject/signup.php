<?php
require_once 'connection.php';

$firstname = '';
$lastname  = '';
$username  = '';
$email     = '';
$errors    = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Trim input
    $firstname = trim($_POST["firstname"] ?? '');
    $lastname  = trim($_POST["lastname"] ?? '');
    $username  = trim($_POST["username"] ?? '');
    $email     = trim($_POST["email"] ?? '');
    $password  = $_POST["password"] ?? '';
    $confirm   = $_POST["confirm_password"] ?? '';

    // 1) Required fields
    if ($firstname === '' || $lastname === '' || $username === '' || $email === '' || $password === '' || $confirm === '') {
        $errors[] = "All fields are required.";
    }

    // 2) Email format
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    // 3) Username length (4–30 chars)
    if ($username !== '' && (strlen($username) < 4 || strlen($username) > 30)) {
        $errors[] = "Username must be between 4 and 30 characters.";
    }

    // 4) Password length & strength
    if ($password !== '') {
        if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 characters long.";
        }
        // must contain at least one letter and one number
        if (!preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
            $errors[] = "Password must contain at least one letter and one number.";
        }
    }

    // 5) Confirmation match
    if ($password !== '' && $confirm !== '' && $password !== $confirm) {
        $errors[] = "Password and confirmation do not match.";
    }

    // 6) Check if username or email already exists
    if (empty($errors)) {
        $checkSql = "SELECT id, username, email FROM users WHERE username = ? OR email = ?";
        $checkStmt = $conn->prepare($checkSql);
        if ($checkStmt) {
            $checkStmt->bind_param("ss", $username, $email);
            $checkStmt->execute();
            $result = $checkStmt->get_result();
            if ($row = $result->fetch_assoc()) {
                if ($row['username'] === $username) {
                    $errors[] = "That username is already taken.";
                }
                if ($row['email'] === $email) {
                    $errors[] = "That email is already registered. Try logging in.";
                }
            }
        } else {
            $errors[] = "Database error. Please try again.";
        }
    }

    // 7) If everything is OK, hash password and insert
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (firstname, lastname, username, email, password, role)
                VALUES (?, ?, ?, ?, ?, 'user')";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("sssss", $firstname, $lastname, $username, $email, $hash);
            if ($stmt->execute()) {
                // After successful signup, send user to login
                header("Location: login.php");
                exit();
            } else {
                $errors[] = "Error creating account. Please try again.";
            }
        } else {
            $errors[] = "Database error. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up - Game Zone</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="mainbody">
    <div class="form-container">
        <h2>Create Account</h2>

        <?php if (!empty($errors)): ?>
            <p style="color:red;">
                <?php echo htmlspecialchars(implode(' ', $errors)); ?>
            </p>
        <?php endif; ?>

        <form method="POST" action="signup.php">
            <input
                type="text"
                name="firstname"
                placeholder="First Name"
                value="<?php echo htmlspecialchars($firstname); ?>"
                required
            >
            <input
                type="text"
                name="lastname"
                placeholder="Last Name"
                value="<?php echo htmlspecialchars($lastname); ?>"
                required
            >
            <input
                type="text"
                name="username"
                placeholder="Username"
                value="<?php echo htmlspecialchars($username); ?>"
                required
            >
            <input
                type="email"
                name="email"
                placeholder="Email"
                value="<?php echo htmlspecialchars($email); ?>"
                required
            >
            <input
                type="password"
                name="password"
                placeholder="Password"
                required
            >
            <input
                type="password"
                name="confirm_password"
                placeholder="Confirm Password"
                required
            >
            <button type="submit">Sign Up</button>
        </form>

        <p>Already have an account? <a href="login.php">Login</a></p>
    </div>
</body>
</html>
