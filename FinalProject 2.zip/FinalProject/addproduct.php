<?php
session_start();
require_once 'connection.php';

// Security Check
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name        = trim($_POST['name'] ?? '');
    $price       = trim($_POST['price'] ?? '');
    $saleprice   = trim($_POST['saleprice'] ?? '');
    $platform    = trim($_POST['platform'] ?? '');
    $category    = trim($_POST['category'] ?? '');
    $quantity    = trim($_POST['quantity'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $imageurl    = trim($_POST['imageurl'] ?? '');
    $ispreowned  = isset($_POST['ispreowned']) ? 1 : 0;

    // Required fields
    if ($name === '' || $price === '' || $platform === '' || $category === '' || $quantity === '' || $imageurl === '') {
        $errors[] = "Name, price, platform, category, quantity, and image URL are required.";
    }

    // Length checks
    if ($name !== '' && strlen($name) > 255) {
        $errors[] = "Product name is too long (max 255 characters).";
    }
    if ($imageurl !== '' && strlen($imageurl) > 255) {
        $errors[] = "Image URL is too long (max 255 characters).";
    }

    // Numeric validation
    if ($price !== '') {
        if (!is_numeric($price) || (float)$price <= 0) {
            $errors[] = "Price must be a positive number.";
        }
    }

    if ($saleprice === '') {
        $saleprice = 0;
    } else {
        if (!is_numeric($saleprice) || (float)$saleprice < 0) {
            $errors[] = "Sale price must be a number greater than or equal to 0.";
        } elseif (is_numeric($price) && (float)$saleprice > (float)$price) {
            $errors[] = "Sale price cannot be greater than the regular price.";
        }
    }

    if ($quantity !== '') {
        if (!ctype_digit($quantity) || (int)$quantity < 0) {
            $errors[] = "Quantity must be a non-negative whole number.";
        }
    }

    if (empty($errors)) {
        $priceVal     = (float)$price;
        $salepriceVal = (float)$saleprice;
        $quantityVal  = (int)$quantity;

        $sql = "INSERT INTO products (name, price, saleprice, platform, category, quantity, imageurl, ispreowned, description)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param(
                "sddssisis",
                $name,
                $priceVal,
                $salepriceVal,
                $platform,
                $category,
                $quantityVal,
                $imageurl,
                $ispreowned,
                $description
            );

            if ($stmt->execute()) {
                header("Location: admin.php");
                exit;
            } else {
                $errors[] = "Error inserting product: " . $conn->error;
            }
        } else {
            $errors[] = "Database error: could not prepare statement.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f4f6;
        }
        .page-wrapper {
            max-width: 900px;
            margin: 30px auto;
            padding: 0 15px;
        }
        .card {
            background: #ffffff;
            border-radius: 10px;
            padding: 20px 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        h1 {
            margin-bottom: 15px;
            text-align: center;
        }
        .subtitle {
            text-align: center;
            color: #555;
            margin-bottom: 20px;
            font-size: 0.95rem;
        }
        form .form-group {
            margin-bottom: 12px;
        }
        form label {
            display: block;
            font-weight: bold;
            margin-bottom: 4px;
        }
        form input[type="text"],
        form input[type="number"],
        form textarea {
            width: 100%;
            padding: 8px 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 0.95rem;
        }
        textarea {
            resize: vertical;
        }
        .inline-row {
            display: flex;
            gap: 10px;
        }
        .inline-row .form-group {
            flex: 1;
        }
        .checkbox-row {
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .checkbox-row input[type="checkbox"] {
            width: auto;
        }
        .btn-primary {
            background: #2563eb;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.95rem;
        }
        .btn-primary:hover {
            background: #1d4ed8;
        }
        .back-link {
            margin-top: 15px;
            text-align: center;
        }
        .back-link a {
            color: #2563eb;
            text-decoration: none;
        }
        .error-box {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #b91c1c;
            padding: 10px 12px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<div class="page-wrapper">
    <div class="card">
        <h1>Add New Product</h1>
        <p class="subtitle">Fill out the details below to add a new game or console to the store.</p>

        <?php if (!empty($errors)): ?>
            <div class="error-box">
                <?php echo htmlspecialchars(implode(' ', $errors)); ?>
            </div>
        <?php endif; ?>

        <form method="post" action="addproduct.php">
            <div class="form-group">
                <label>Product Name *</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($name ?? ''); ?>" required>
            </div>

            <div class="inline-row">
                <div class="form-group">
                    <label>Platform *</label>
                    <input type="text" name="platform" placeholder="playstation, Xbox, etc."
                           value="<?php echo htmlspecialchars($platform ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label>Category *</label>
                    <input type="text" name="category" placeholder="game, console, etc."
                           value="<?php echo htmlspecialchars($category ?? ''); ?>" required>
                </div>
            </div>

            <div class="inline-row">
                <div class="form-group">
                    <label>Price * ($)</label>
                    <input type="number" step="0.01" name="price"
                           value="<?php echo htmlspecialchars($price ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label>Sale Price ($, optional)</label>
                    <input type="number" step="0.01" name="saleprice"
                           value="<?php echo htmlspecialchars($saleprice ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Quantity * (in stock)</label>
                    <input type="number" name="quantity" min="0"
                           value="<?php echo htmlspecialchars($quantity ?? ''); ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label>Image URL *</label>
                <input type="text" name="imageurl"
                       value="<?php echo htmlspecialchars($imageurl ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label>Description (optional)</label>
                <textarea name="description" rows="4"><?php echo htmlspecialchars($description ?? ''); ?></textarea>
            </div>

            <div class="checkbox-row">
                <input type="checkbox" name="ispreowned" <?php if (!empty($ispreowned)) echo 'checked'; ?>>
                <span>Is Pre-Owned?</span>
            </div>

            <div style="margin-top:18px; text-align:center;">
                <button type="submit" class="btn-primary">Add Product</button>
            </div>
        </form>

        <div class="back-link">
            <a href="admin.php">&larr; Back to Admin Panel</a>
        </div>
    </div>
</div>

</body>
</html>
