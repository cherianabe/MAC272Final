<?php
session_start();
require_once 'connection.php';

// Only admins can see this page
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Handle delete action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $deleteId = $_POST['delete_id'];

    if (ctype_digit($deleteId)) {
        $sql  = "DELETE FROM feedback WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $deleteId);
            $stmt->execute();
        }
    }
}

// Get all feedback (with optional username if user_id is set)
$sql = "
    SELECT f.id, f.name, f.email, f.message, f.created_at, u.username
    FROM feedback f
    LEFT JOIN users u ON f.user_id = u.id
    ORDER BY f.created_at DESC
";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>View Feedback</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f4f6;
        }
        .page-wrapper {
            max-width: 1000px;
            margin: 30px auto;
            padding: 0 15px;
        }
        .card {
            background: #ffffff;
            border-radius: 10px;
            padding: 20px 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        h1 {
            margin-bottom: 10px;
            text-align: center;
        }
        .subtitle {
            text-align: center;
            color: #555;
            margin-bottom: 20px;
            font-size: 0.95rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        th, td {
            border-bottom: 1px solid #e5e7eb;
            padding: 8px 10px;
            vertical-align: top;
            text-align: left;
        }
        th {
            background: #f9fafb;
            font-weight: bold;
        }
        .message-cell {
            max-width: 400px;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .badge {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 999px;
            font-size: 0.75rem;
            background: #e5e7eb;
            color: #374151;
        }
        .btn-delete {
            background: #ef4444;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 4px 8px;
            cursor: pointer;
            font-size: 0.8rem;
        }
        .btn-delete:hover {
            background: #dc2626;
        }
        .back-link {
            margin-top: 15px;
            text-align: center;
        }
        .back-link a {
            color: #2563eb;
            text-decoration: none;
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="page-wrapper">
    <div class="card">
        <h1>Feedback Submissions</h1>
        <p class="subtitle">View messages submitted through the contact/feedback form.</p>

        <?php if ($result && $result->num_rows > 0): ?>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Submitted By</th>
                    <th>Email</th>
                    <th>Username (if logged in)</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td>
                            <?php if (!empty($row['username'])): ?>
                                <span class="badge"><?php echo htmlspecialchars($row['username']); ?></span>
                            <?php else: ?>
                                <span class="badge">Guest</span>
                            <?php endif; ?>
                        </td>
                        <td class="message-cell">
                            <?php echo nl2br(htmlspecialchars($row['message'])); ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                        <td>
                            <form method="post" action="view_feedback.php" onsubmit="return confirm('Delete this feedback entry?');">
                                <input type="hidden" name="delete_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No feedback has been submitted yet.</p>
        <?php endif; ?>

        <div class="back-link">
            <a href="admin.php">&larr; Back to Admin Panel</a>
        </div>
    </div>
</div>

</body>
</html>
