<?php
session_start();
require_once 'connection.php';

$username = '';
$error    = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Required validation
    if ($username === '' || $password === '') {
        $error = "Please enter both username and password.";
    } else {
        // Get user by username
        $sql = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($row = $result->fetch_assoc()) {
                $dbPassword = $row['password'];
                $loginOk = false;

                // 1) Try hashed verification first
                if (password_verify($password, $dbPassword)) {
                    $loginOk = true;
                } else {
                    // 2) Fallback: for any existing plain-text passwords (like seeded admin)
                    if ($password === $dbPassword) {
                        $loginOk = true;
                    }
                }

                if ($loginOk) {
                    // Set session variables
                    $_SESSION['loggedin'] = true;
                    $_SESSION['id']       = $row['id'];
                    $_SESSION['username'] = $row['username'];
                    $_SESSION['role']     = $row['role']; // 'user' or 'admin'

                    if ($row['role'] === 'admin') {
                        header("Location: admin.php");
                    } else {
                        header("Location: home.php");
                    }
                    exit;
                } else {
                    $error = "Invalid username or password.";
                }

            } else {
                $error = "Invalid username or password.";
            }
        } else {
            $error = "Database error. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login - Game Zone</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="mainbody">
    
    <div class="form-container">
        <h2>Login to Game Zone</h2>
        <?php if(isset($error)) echo "<p style='color:red'>$error</p>"; ?>
        <form method="POST" action="login.php">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <p>No account? <a href="signup.php">Sign Up</a></p>
        <p><a href="home.php">Back to Home</a></p>
    </div>

</body>
</html>