<?php
session_start();
require_once 'connection.php';

// 1) Must be logged in and have items in the cart
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || empty($_SESSION['cart'])) {
    header("Location: home.php");
    exit;
}

$user_id = $_SESSION['id'];   // set in login.php
$total   = 0.0;

// We'll store cart item details here so we can insert into order_items later
$orderItems = [];

// 2) First pass: validate stock and calculate totals
foreach ($_SESSION['cart'] as $product_id => $quantity) {

    // Skip anything weird
    $product_id = (int)$product_id;
    $quantity   = (int)$quantity;
    if ($quantity <= 0) {
        continue;
    }

    // Get product info
    $sql = "SELECT name, price, saleprice, quantity FROM products WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if (!$result || $result->num_rows === 0) {
        // Product not found in DB – bail out
        $stmt->close();
        echo "<script>
            alert('One of the products in your cart could not be found. Please review your cart.');
            window.location.href='cart.php';
        </script>";
        exit;
    }

    $row = $result->fetch_assoc();
    $stmt->close();

    // Check stock
    if ($row['quantity'] < $quantity) {
        // Not enough stock – tell the user and send them back to cart
        $available = (int)$row['quantity'];
        echo "<script>
            alert('Sorry, we only have {$available} of \"{$row['name']}\" left in stock. Please update your cart.');
            window.location.href='cart.php';
        </script>";
        exit;
    }

    // Decide which price to use: saleprice if > 0, else regular price
    $unit_price = ($row['saleprice'] > 0) ? (float)$row['saleprice'] : (float)$row['price'];
    $line_total = $unit_price * $quantity;

    $total += $line_total;

    // Save details so we can insert into order_items after we create the order
    $orderItems[] = [
        'product_id' => $product_id,
        'quantity'   => $quantity,
        'unit_price' => $unit_price,
        'line_total' => $line_total
    ];
}

// If somehow no valid items, send back home
if ($total <= 0 || empty($orderItems)) {
    echo "<script>
        alert('Your cart appears to be empty or invalid.');
        window.location.href='home.php';
    </script>";
    exit;
}

// OPTIONAL: you could start a transaction here if you want everything to be all-or-nothing.
// $conn->begin_transaction();

//
// 3) Subtract stock from products table
//
foreach ($orderItems as $item) {
    $sql = "UPDATE products SET quantity = quantity - ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        // $conn->rollback(); // if using transactions
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("ii", $item['quantity'], $item['product_id']);
    $stmt->execute();
    $stmt->close();
}

//
// 4) Create an order row in the ORDERS table
//
$sql = "INSERT INTO orders (user_id, total) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    // $conn->rollback(); // if using transactions
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("id", $user_id, $total);
$stmt->execute();
$order_id = $stmt->insert_id;   // <-- this is the Order ID
$stmt->close();

//
// 5) Insert each item into ORDER_ITEMS table
//
$sql = "INSERT INTO order_items (order_id, product_id, quantity, unit_price, line_total)
        VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    // $conn->rollback(); // if using transactions
    die("Prepare failed: " . $conn->error);
}

foreach ($orderItems as $item) {
    $stmt->bind_param(
        "iiidd",
        $order_id,
        $item['product_id'],
        $item['quantity'],
        $item['unit_price'],
        $item['line_total']
    );
    $stmt->execute();
}
$stmt->close();

// If using transactions, you'd commit here:
// $conn->commit();

//
// 6) Empty the cart
//
unset($_SESSION['cart']);

//
// 7) Redirect with Order ID shown in alert
//
echo "<script>
alert('Thank you for your purchase! Your Order ID is #{$order_id}.');
window.location.href='home.php';
</script>";
?>
