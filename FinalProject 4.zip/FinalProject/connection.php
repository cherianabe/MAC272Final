 <?php
// --- BASIC CONNECTION SETTINGS ---
// Change these ONLY if the MySQL username/password are different
$servername = "localhost";
$username   = "root";
$password   = ""; 
$dbname     = "finalproject";

// 1) Connect to MySQL server (without selecting a DB yet)
$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2) Create the database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS `$dbname`";
if (!$conn->query($sql)) {
    die("Error creating database: " . $conn->error);
}

// 3) Select the database
if (!$conn->select_db($dbname)) {
    die("Error selecting database: " . $conn->error);
}

// 4) Create USERS table (for login/signup/admin) if it does not exist
$usersTableSql = "
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(100) NOT NULL,
    lastname  VARCHAR(100) NOT NULL,
    username  VARCHAR(100) NOT NULL UNIQUE,
    email     VARCHAR(255) NOT NULL,
    password  VARCHAR(255) NOT NULL,
    role      ENUM('user','admin') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if (!$conn->query($usersTableSql)) {
    die('Error creating users table: ' . $conn->error);
}

// 5) Create PRODUCTS table (this is where stock lives) if it does not exist
// NOTE: category/platform are VARCHAR so they can match your existing queries
// (e.g. category = 'game', platform = 'playstation')
$productsTableSql = "
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(255) NOT NULL,
    price      DECIMAL(10,2) NOT NULL,
    saleprice  DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    platform   VARCHAR(20),
    category   VARCHAR(20) NOT NULL,
    quantity   INT NOT NULL DEFAULT 0,
    imageurl   VARCHAR(255) NOT NULL,
    ispreowned TINYINT(1) NOT NULL DEFAULT 0,
    description TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if (!$conn->query($productsTableSql)) {
    die('Error creating products table: ' . $conn->error);
}

// 6) SEED DATA ONLY IF TABLES ARE EMPTY
// -------------------------------------------------
// 6a) Seed an admin user if no users exist
$result = $conn->query("SELECT COUNT(*) AS c FROM users");
if ($result) {
    $row = $result->fetch_assoc();
    if ((int)$row['c'] === 0) {
        // secure hashed password for the seeded admin
$adminPasswordHash = password_hash('admin123', PASSWORD_DEFAULT);

$adminSql = "
    INSERT INTO users (firstname, lastname, username, email, password, role)
    VALUES ('Admin', 'User', 'admin', 'admin@example.com', '$adminPasswordHash', 'admin')
";
$conn->query($adminSql);
// login: username = admin, password = admin123

    }
}

// 6b) Seed products (games & consoles) if none exist
$result = $conn->query("SELECT COUNT(*) AS c FROM products");
if ($result) {
    $row = $result->fetch_assoc();
    if ((int)$row['c'] === 0) {

        // IMPORTANT:
        // - platform 'playstation' and category 'game' are LOWERCASE
        //   to match queries like: WHERE platform = 'playstation' AND category = 'game'
        // - ispreowned = 1 for preowned, saleprice > 0 for deals
        $productsSeedSql = "
        INSERT INTO products
        (name, price, saleprice, platform, category, quantity, imageurl, ispreowned, description)
        VALUES
        -- PlayStation games (new, not on sale)
        ('Ratchet & Clank: Rift Apart', 69.99, 0.00, 'playstation', 'game', 12,
         'images/playstation/rachetandclank.jpg', 0,
         'Blast through dimensions with Ratchet & Clank in this fast-paced action platformer.'),
        ('Horizon Forbidden West',      69.99, 0.00, 'playstation', 'game', 15,
         'images/playstation/horizonforbiddenwest.jpg', 0,
         'Join Aloy on her journey into the Forbidden West, filled with new machines and mysteries.'),
        ('Final Fantasy XVI',           69.99, 0.00, 'playstation', 'game', 10,
         'images/playstation/finalfantasyXVI.jpg', 0,
         'The next mainline entry in the legendary Final Fantasy series.'),
        ('Demon''s Souls',              69.99, 0.00, 'playstation', 'game', 8,
         'images/playstation/demonssouls.jpg', 0,
         'The brutal, gorgeous remake of the PS3 classic action-RPG.'),
        ('Returnal',                    69.99, 0.00, 'playstation', 'game', 9,
         'images/playstation/returnal.jpg', 0,
         'Roguelike sci-fi shooter where you relive a hostile alien world on every death.'),

        -- Xbox games (new, not on sale)
        ('Star Wars Outlaws', 69.99, 0.00, 'Xbox', 'game', 10,
         'images/xbox/starwarsOutlaws.jpg', 0,
         'An open-world Star Wars adventure set between Empire and Jedi.'),
        ('Halo Infinite',     59.99, 0.00, 'Xbox', 'game', 14,
         'images/xbox/haloinfinite.jpg', 0,
         'Master Chief returns in the next chapter of the Halo saga.'),
        ('FC 25',             69.99, 0.00, 'Xbox', 'game', 20,
         'images/xbox/fc25.jpg', 0,
         'Next-gen football experience with updated rosters and modes.'),
        ('Gears 5',           39.99, 0.00, 'Xbox', 'game', 7,
         'images/xbox/gears5.jpg', 0,
         'The Coalition continues the iconic Gears of War series.'),
        ('Starfield',         69.99, 0.00, 'Xbox', 'game', 11,
         'images/xbox/starfield.jpg', 0,
         'Explore the galaxy in Bethesda''s massive sci-fi RPG.'),

        -- Hot deals (saleprice > 0, show in deals.php)
        ('Red Dead Redemption 2', 59.99, 39.99, 'playstation', 'game', 10,
         'images/deals/reddeadredemption2.jpg', 0,
         'Epic open-world western with a gripping story.'),
        ('NBA 2K25',              69.99, 49.99, 'playstation', 'game', 15,
         'images/deals/nba2k25.jpg', 0,
         'Next-gen basketball sim with updated rosters and modes.'),
        ('College Football 2025', 69.99, 44.99, 'Xbox', 'game', 8,
         'images/deals/collegefootball2025.jpg', 0,
         'Experience college football with authentic teams and stadiums.'),
        ('Final Fantasy VII Rebirth', 69.99, 54.99, 'playstation', 'game', 9,
         'images/deals/finalfantasyrebirth.jpg', 0,
         'The second part of the reimagining of Final Fantasy VII.'),
        ('Grand Theft Auto V',    39.99, 19.99, 'Xbox', 'game', 20,
         'images/deals/gtaV.jpg', 0,
         'Open-world crime sandbox classic at a bargain price.'),

        -- Pre-owned games (ispreowned = 1, show in pre-owned.php)
        ('Battlefield 2042', 39.99, 24.99, 'Xbox', 'game', 6,
         'images/preowned/battlefield2042.jpg', 1,
         'Pre-owned copy, tested and cleaned. Large-scale multiplayer battles.'),
        ('Goat Simulator 3', 29.99, 14.99, 'playstation', 'game', 5,
         'images/preowned/goatsimulator3.jpg', 1,
         'Ridiculous sandbox chaos starring a very determined goat.'),
        ('Black Myth: Wukong', 69.99, 39.99, 'playstation', 'game', 4,
         'images/preowned/blackmythwukong.jpg', 1,
         'Action RPG inspired by Journey to the West, pre-owned but in great shape.'),
        ('Until Dawn',        19.99, 9.99,  'playstation', 'game', 7,
         'images/preowned/untildawn.jpg', 1,
         'Cinematic horror adventure where your choices matter.'),
        ('Astro Bot',         59.99, 34.99, 'playstation', 'game', 3,
         'images/preowned/astrobot.jpg', 1,
         'Charming 3D platformer; pre-owned disc in excellent condition.'),

        -- Consoles (not currently used by consoles.php, but available in DB/admin)
        ('PlayStation 5 (Disc Edition)', 499.99, 0.00, 'playstation', 'console', 5,
         'images/consoles/playstation5gamediscedition.jpg', 0,
         'PS5 with disc drive, 4K gaming and ultra-fast SSD.'),
        ('PlayStation 5 (Digital Edition)', 449.99, 0.00, 'playstation', 'console', 3,
         'images/consoles/playstation5digitaledition.jpg', 0,
         'Digital-only version of the PS5, no disc drive.'),
        ('Xbox Series X', 499.99, 0.00, 'Xbox', 'console', 4,
         'images/consoles/xboxseriesx.jpg', 0,
         'The most powerful Xbox, with 4K and high frame rate support.'),
        ('Xbox Series S', 299.99, 0.00, 'Xbox', 'console', 6,
         'images/consoles/xboxseriess.jpg', 0,
         'Compact, all-digital next-gen Xbox with great performance.')
        ";
        
        if (!$conn->query($productsSeedSql)) {
            // For debugging during development you could uncomment this:
            // die('Error inserting seed products: ' . $conn->error);
        }
    }
}

// 5c) Create ORDERS table (tracks orders with an Order ID)
$ordersTableSql = "
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Completed',
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if (!$conn->query($ordersTableSql)) {
    die('Error creating orders table: ' . $conn->error);
}

// 5d) Create FEEDBACK table (stores user feedback)
$feedbackTableSql = "
CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";


if (!$conn->query($feedbackTableSql)) {
    die('Error creating feedback table: ' . $conn->error);
}

// 5d) Create FEEDBACK table (stores user feedback)
$feedbackTableSql = "
CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if (!$conn->query($feedbackTableSql)) {
    die('Error creating feedback table: ' . $conn->error);
}



// 5e) Create ORDER_ITEMS table (line items per order)
$orderItemsTableSql = "
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id  INT NOT NULL,
    product_id INT NOT NULL,
    quantity  INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    line_total DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id)  REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if (!$conn->query($orderItemsTableSql)) {
    die('Error creating order_items table: ' . $conn->error);
}


// 5f) Create SHIPPING_ADDRESSES table (user shipping info)
$shippingAddressesTableSql = "
CREATE TABLE IF NOT EXISTS shipping_addresses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    address_line1 VARCHAR(255) NOT NULL,
    address_line2 VARCHAR(255) NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    postal_code VARCHAR(20) NOT NULL,
    country VARCHAR(100) NOT NULL DEFAULT 'USA',
    phone VARCHAR(30) NULL,
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if (!$conn->query($shippingAddressesTableSql)) {
    die('Error creating shipping_addresses table: ' . $conn->error);
}


// 5g) Create PRODUCT_REVIEWS table (user reviews for products)
$productReviewsTableSql = "
CREATE TABLE IF NOT EXISTS product_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    rating TINYINT NOT NULL,
    title VARCHAR(255) NULL,
    body TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if (!$conn->query($productReviewsTableSql)) {
    die('Error creating product_reviews table: ' . $conn->error);
}


// 5h) Create WISHLISTS table (saved items per user)
$wishlistsTableSql = "
CREATE TABLE IF NOT EXISTS wishlists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if (!$conn->query($wishlistsTableSql)) {
    die('Error creating wishlists table: ' . $conn->error);
}


// 5i) Create COUPONS table (promo codes)
$couponsTableSql = "
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255) NULL,
    discount_type ENUM('percent','fixed') NOT NULL,
    discount_amount DECIMAL(10,2) NOT NULL,
    min_order_total DECIMAL(10,2) DEFAULT 0.00,
    start_date DATE NULL,
    end_date DATE NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if (!$conn->query($couponsTableSql)) {
    die('Error creating coupons table: ' . $conn->error);
}



// At this point:
// - $conn is ready
// - DB and tables exist
// - Initial data is in place (if it wasn't already)
?>
