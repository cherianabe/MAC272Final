<?php
require_once 'connection.php';

$errors = [];
$firstname = $lastname = $username = $email = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Trim inputs
    $firstname = trim($_POST["firstname"] ?? '');
    $lastname  = trim($_POST["lastname"] ?? '');
    $username  = trim($_POST["username"] ?? '');
    $email     = trim($_POST["email"] ?? '');
    $password  = $_POST["password"] ?? '';
    $confirm   = $_POST["confirm_password"] ?? '';

    // 1) Required fields
    if ($firstname === '') $errors['firstname'] = "First name is required.";
    if ($lastname === '')  $errors['lastname']  = "Last name is required.";
    if ($username === '')  $errors['username']  = "Username is required.";
    if ($email === '')     $errors['email']     = "Email is required.";
    if ($password === '')  $errors['password']  = "Password is required.";
    if ($confirm === '')   $errors['confirm']   = "Please confirm your password.";

    // 2) Email format
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Please enter a valid email address.";
    }

    // 3) Username length (3–20 characters)
    if ($username !== '' && (strlen($username) < 3 || strlen($username) > 20)) {
        $errors['username'] = "Username must be between 3 and 20 characters.";
    }

    // 4) Password strength: at least 8 chars, includes letters and numbers
    if ($password !== '') {
        if (strlen($password) < 8) {
            $errors['password'] = "Password must be at least 8 characters.";
        } elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
            $errors['password'] = "Password must contain letters and numbers.";
        }
    }

    // 5) Confirmation matches
    if ($password !== '' && $confirm !== '' && $password !== $confirm) {
        $errors['confirm'] = "Passwords do not match.";
    }

    // Optional: check that username/email are unique
    if (empty($errors)) {
        $checkSql = "SELECT id FROM users WHERE username = ? OR email = ?";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->bind_param("ss", $username, $email);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        if ($checkResult->num_rows > 0) {
            $errors['username'] = "Username or email already exists.";
        }
        $checkStmt->close();
    }

    // If no errors, insert with hashed password
    if (empty($errors)) {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (firstname, lastname, username, email, password, role) 
                VALUES (?, ?, ?, ?, ?, 'user')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $firstname, $lastname, $username, $email, $passwordHash);

        if ($stmt->execute()) {
            header("Location: login.php");
            exit;
        } else {
            $errors['general'] = "Error creating account. Please try again.";
        }
        $stmt->close();
    }
}
?>


<!DOCTYPE html>
<body class="mainbody">
    <div class="form-container">
        <h2>Create Account</h2>

        <?php if (!empty($errors['general'])): ?>
            <p style="color:red;"><?php echo $errors['general']; ?></p>
        <?php endif; ?>

        <form method="POST" action="signup.php">
            <input type="text" name="firstname" placeholder="First Name"
                   value="<?php echo htmlspecialchars($firstname); ?>" required>
            <?php if (!empty($errors['firstname'])) echo "<p style='color:red'>{$errors['firstname']}</p>"; ?>

            <input type="text" name="lastname" placeholder="Last Name"
                   value="<?php echo htmlspecialchars($lastname); ?>" required>
            <?php if (!empty($errors['lastname'])) echo "<p style='color:red'>{$errors['lastname']}</p>"; ?>

            <input type="text" name="username" placeholder="Username"
                   value="<?php echo htmlspecialchars($username); ?>" required>
            <?php if (!empty($errors['username'])) echo "<p style='color:red'>{$errors['username']}</p>"; ?>

            <input type="email" name="email" placeholder="Email"
                   value="<?php echo htmlspecialchars($email); ?>" required>
            <?php if (!empty($errors['email'])) echo "<p style='color:red'>{$errors['email']}</p>"; ?>

            <input type="password" name="password" placeholder="Password" required>
            <?php if (!empty($errors['password'])) echo "<p style='color:red'>{$errors['password']}</p>"; ?>

            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <?php if (!empty($errors['confirm'])) echo "<p style='color:red'>{$errors['confirm']}</p>"; ?>

            <button type="submit">Sign Up</button>
        </form>

        <p>Already have an account? <a href="login.php">Login</a></p>
    </div>
</body>
</html>
