<nav class="navbar">
    <div class="weblogo">
        <a href="home.php"><img src="images/logonavbar/logo.png" alt="logo"></a>
    </div>

    <div class="navbuttons">
        <!-- Search Bar -->
        <form action="search.php" method="get" class="search-form">
            <input type="text" name="q" placeholder="Search games..." required>
            <button type="submit">Search</button>
        </form>

        <button><a href="home.php">Home</a></button>
        <button><a href="feedback.php">Feedback</a></button>

        <div class="dropdown">
            <button class="dropbtn">Videogames</button>
            <div class="dropdown-content">
                <a href="xboxgames.php" id="xboxbtn">Xbox</a>
                <a href="playstationgames.php" id="playbtn">PlayStation</a>
            </div>
        </div>

        <button><a href="consoles.php">Consoles</a></button>
        <button><a href="deals.php">Deals</a></button>
        <button><a href="pre-owned.php">Pre-Owned</a></button>

        <?php
        // cart count
        $cart_count = 0;
        if (!empty($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $item) {
                $cart_count += $item['quantity'];
            }
        }
        ?>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <button><a href="admin.php">Admin</a></button>
        <?php endif; ?>

        <button><a href="cart.php" class="cart-icon">🛒 (<?php echo $cart_count; ?>)</a></button>

        <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
            <button><a href="logout.php">Log Out</a></button>
        <?php else: ?>
            <button><a href="login.php">Log In</a></button>
            <button><a href="signup.php">Sign Up</a></button>
        <?php endif; ?>
    </div>
</nav>
