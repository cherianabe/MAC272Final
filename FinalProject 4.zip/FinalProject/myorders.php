<?php
session_start();
require_once 'connection.php';

// 1) Must be logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['id']; // set in login.php

// 2) Get all orders for this user
$orders = [];
$sql = "SELECT id, total, created_at, status 
        FROM orders 
        WHERE user_id = ? 
        ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}
$stmt->close();

// 3) For each order, get its items from order_items + products
foreach ($orders as $index => $order) {
    $order_id = (int)$order['id'];

    $sqlItems = "SELECT oi.quantity, oi.unit_price, oi.line_total,
                        p.name AS product_name
                 FROM order_items oi
                 JOIN products p ON oi.product_id = p.id
                 WHERE oi.order_id = ?";
    $stmtItems = $conn->prepare($sqlItems);
    if (!$stmtItems) {
        die("Prepare failed: " . $conn->error);
    }
    $stmtItems->bind_param("i", $order_id);
    $stmtItems->execute();
    $resultItems = $stmtItems->get_result();

    $items = [];
    while ($itemRow = $resultItems->fetch_assoc()) {
        $items[] = $itemRow;
    }
    $stmtItems->close();

    $orders[$index]['items'] = $items;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Orders - Game Zone</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .orders-wrapper {
            padding: 50px;
            color: white;
        }
        .order-card {
            background: rgba(0, 0, 0, 0.7);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 25px;
            border: 1px solid #444;
        }
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #555;
            padding-bottom: 8px;
            margin-bottom: 10px;
        }
        .order-header h3 {
            margin: 0;
            color: #FFEB3B;
        }
        .order-meta {
            font-size: 14px;
            color: #ccc;
        }
        .order-status {
            font-weight: bold;
            padding: 3px 8px;
            border-radius: 4px;
            background-color: #FF6F61;
            color: white;
            font-size: 12px;
        }
        .order-total {
            font-weight: bold;
            font-size: 18px;
            color: #66FF00;
        }
        .order-items-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background: white;
            color: black;
        }
        .order-items-table th,
        .order-items-table td {
            padding: 8px 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .order-items-table th {
            background-color: #FF6F61;
            color: white;
        }
        .no-orders {
            text-align: center;
            margin-top: 80px;
            font-size: 20px;
        }
        .back-link {
            margin-top: 20px;
            text-align: center;
        }
        .back-link a {
            color: #FFEB3B;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body class="mainbody">

    <?php include 'navbar.php'; ?>

    <div class="maincontent">
        <div class="orders-wrapper">
            <h2 style="color:#FFEB3B; border-bottom:2px solid white; padding-bottom:10px;">
                My Orders
            </h2>

            <?php if (empty($orders)): ?>
                <div class="no-orders">
                    <p>You have not placed any orders yet.</p>
                    <p><a href="home.php" style="color:#FFEB3B; text-decoration:none;">Start shopping 🎮</a></p>
                </div>
            <?php else: ?>
                <?php foreach ($orders as $order): ?>
                    <div class="order-card">
                        <div class="order-header">
                            <div>
                                <h3>Order #<?php echo htmlspecialchars($order['id']); ?></h3>
                                <div class="order-meta">
                                    Placed on: 
                                    <?php 
                                        if (!empty($order['created_at'])) {
                                            echo date('M d, Y h:i A', strtotime($order['created_at']));
                                        } else {
                                            echo "N/A";
                                        }
                                    ?>
                                </div>
                            </div>
                            <div style="text-align:right;">
                                <div class="order-status">
                                    <?php echo htmlspecialchars($order['status']); ?>
                                </div>
                                <div class="order-total">
                                    Total: $<?php echo number_format((float)$order['total'], 2); ?>
                                </div>
                            </div>
                        </div>

                        <?php if (!empty($order['items'])): ?>
                            <table class="order-items-table">
                                <thead>
                                    <tr>
                                        <th>Item</th>
                                        <th>Quantity</th>
                                        <th>Unit Price</th>
                                        <th>Line Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($order['items'] as $item): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                            <td><?php echo (int)$item['quantity']; ?></td>
                                            <td>$<?php echo number_format((float)$item['unit_price'], 2); ?></td>
                                            <td>$<?php echo number_format((float)$item['line_total'], 2); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <p style="color:#ccc; font-size:14px;">No item details found for this order.</p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <div class="back-link">
                <p><a href="home.php">⬅ Back to Home</a></p>
            </div>
        </div>
    </div>

</body>
</html>
